public class StudentInfo {

    public static void display() {

	System.out.println("************************************************************");
	System.out.println("*                                                          *");
	System.out.println("*              Brennan McDonald - 8195614                  *");
	System.out.println("*              Alex Kozak - 8311230                        *");
	System.out.println("*                                                          *");
	System.out.println("************************************************************");
	System.out.println();

    }

}